---
name: Executive Precision
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#341100'
  on-tertiary-container: '#d95f00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#783200'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.03em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: '0'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style

The design system is engineered for executive-level decision-making, emphasizing clarity, authority, and high-velocity workflows. The aesthetic is a fusion of **Modern Corporate** and **Minimalism**, heavily inspired by the precision of financial interfaces and engineering tools.

The visual narrative centers on "The Informed Assistant"—a tool that feels quiet when idle but authoritative when providing insights. We achieve this through:
- **Ultra-Clean Density:** High information density without clutter, utilizing significant whitespace to separate distinct functional areas.
- **Micro-Precision:** Every element exists on a strict grid with 1px hairline strokes, avoiding heavy shadows or decorative gradients.
- **Executive Polish:** A focus on "digital craft"—perfect alignment, subtle transitions, and a lack of ornamental distraction.

## Colors

The palette is anchored in **Deep Navy** to establish professional gravity. 

- **Primary (#0F172A):** Used for typography, navigation backgrounds, and primary brand moments.
- **Blue Accent (#3B82F6):** Reserved for growth indicators, primary CTAs, and active states. It represents progress.
- **Critical Orange (#F97316):** Used sparingly for urgent alerts, negative growth, or destructive actions to ensure high-contrast visibility against the navy/white base.
- **Neutral System:** A sophisticated range of grays (Slate and Gray scales) creates hierarchy. In Dark Mode, surfaces transition from #0F172A to #1E293B to create depth without losing the premium "Midnight" feel.

## Typography

This design system uses **Inter** exclusively to maintain a systematic, neutral, and highly legible interface.

- **Headings:** Use tight negative letter-spacing (-0.02em to -0.04em) to create a "compact" and authoritative editorial look. 
- **Body Text:** Uses generous leading (150%+) to ensure readability during long data-review sessions.
- **Labels:** Small caps or uppercase with increased tracking are used for metadata and table headers to distinguish them from actionable content.
- **Numerical Data:** For dashboards, tabular lining figures should be enabled to ensure numbers align perfectly in columns.

## Layout & Spacing

The layout follows a strict **8px Grid System**, ensuring all components are multiples of 8 for visual harmony.

- **Grid Model:** A 12-column fluid grid for desktop/tablet and a 4-column fluid grid for mobile.
- **Padding:** Containers use `lg` (24px) or `xl` (40px) padding to evoke a "premium gallery" feel, moving away from cramped, data-heavy legacy enterprise software.
- **Rhythm:** Vertical rhythm is maintained by using `md` (16px) spacing between related elements and `xl` (40px) between major sections.

## Elevation & Depth

Hierarchy is achieved through **Tonal Layering** and **Low-Contrast Outlines** rather than aggressive shadows.

- **Surface Tiers:** On light mode, the base is #F8FAFC, with cards sitting on #FFFFFF. In dark mode, the base is #0F172A, with cards on #1E293B.
- **Borders:** Every card and interactive element features a 1px border (`#E2E8F0` in light, `rgba(255,255,255,0.1)` in dark). This "hairline" aesthetic defines the premium look.
- **Shadows:** Use a single "Ambient Shadow" for floating modals: `0px 4px 20px rgba(0, 0, 0, 0.05)`. Avoid shadows on standard cards to maintain a flat, architectural feel.

## Shapes

The shape language is controlled and modern. 

- **Standard Elements:** Buttons, inputs, and small cards use a **8px (0.5rem)** radius.
- **Large Containers:** Section containers and large dashboard widgets use a **12px (0.75rem)** radius.
- **Interactive States:** When hovered or focused, the border-weight remains 1px, but the color shifts to the Blue Accent to signal activity without "shifting" the layout.

## Components

### Buttons
- **Primary:** Deep Navy (#0F172A) background with Pure White text. No gradient. High-contrast.
- **Secondary:** White background with 1px #E2E8F0 border and Navy text.
- **Actionable Icons:** Use 20px icons centered in 40px bounding boxes for touch-friendly Android targets.

### Input Fields
- Flat styling with a 1px #E2E8F0 border.
- On focus: Border changes to Blue Accent (#3B82F6) with a 2px outer "glow" of the same color at 10% opacity.

### Dashboard Cards
- Minimalist containers with 24px internal padding.
- Headers within cards should use `label-sm` for categorization and `headline-md` for the primary metric.

### Charts & Data Visualization
- **Line Charts:** 2px stroke width, no area fill, or a very subtle 5% opacity gradient fill.
- **Sparklines:** Used in list views to show 7-day trends; monochromatic (Blue) unless the trend is critical (Orange).
- **Data Points:** Hidden by default, appearing on "touch-and-hold" with a vertical hairline cursor.

### Chips/Badges
- Small 2px radius or pill-shaped.
- Use "Soft Tints": A 10% opacity version of the status color (e.g., 10% Blue for 'In Progress') with the full-saturation color for the text.